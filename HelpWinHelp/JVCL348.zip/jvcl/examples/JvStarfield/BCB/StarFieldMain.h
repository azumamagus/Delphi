/******************************************************************

                       JEDI-VCL Demo

 Copyright (C) 2002 Project JEDI

 Original author:

 Contributor(s):
   korecek: translation from Delphi to BCB

 You may retrieve the latest version of this file at the JEDI-JVCL
 home page, located at http://jvcl.sourceforge.net

 The contents of this file are used with permission, subject to
 the Mozilla Public License Version 1.1 (the "License"); you may
 not use this file except in compliance with the License. You may
 obtain a copy of the License at
 http://www.mozilla.org/MPL/MPL-1_1Final.html

 Software distributed under the License is distributed on an
 "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
 implied. See the License for the specific language governing
 rights and limitations under the License.

******************************************************************/
// $Id$
//---------------------------------------------------------------------------

#ifndef StarFieldMainH
#define StarFieldMainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "JvComponent.hpp"
#include "JvExControls.hpp"
#include "JvStarfield.hpp"
//---------------------------------------------------------------------------
class TStarfieldMainForm : public TForm
{
__published:	// IDE-managed Components
        TJvStarfield *JvStarfield1;
private:	// User declarations
public:		// User declarations
        __fastcall TStarfieldMainForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TStarfieldMainForm *StarfieldMainForm;
//---------------------------------------------------------------------------
#endif
